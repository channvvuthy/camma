const studentProfileData = {
    _id: "",
    date_of_birth: "",
    first_name: "",
    gender: "",
    grade_id: "",
    group_type: "",
    is_login: "",
    last_name: "",
    my_cart: "",
    phone: "",
    school: {
        _id: "",
        name: "CAMMA Microfinance",
    },
    province: {
        _id: "",
        name: "CAMMA Microfinance",
    }
}

export  default {
    studentProfileData
}