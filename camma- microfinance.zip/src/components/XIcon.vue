<template>
    <svg xmlns="http://www.w3.org/2000/svg" :width="width" :height="height" viewBox="0 0 24 24">
        <g :fill="fill">
            <path d="M12 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm0-2c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm6 16.094l-4.157-4.104 4.1-4.141-1.849-1.849-4.105 4.159-4.156-4.102-1.833 1.834 4.161 4.12-4.104 4.157 1.834 1.832 4.118-4.159 4.143 4.102 1.848-1.849z"/>
        </g>
    </svg>
</template>
<script>
    export default{
        name: "XIcon",
        props: {
            width: {
                type: Number,
                default: function () {
                    return 24;
                }
            },
            height: {
                type: Number,
                default: function () {
                    return 24;
                }
            },
            fill: {
                type: String,
                default: function () {
                    return "#000000"
                }
            }
        }
    }
</script>