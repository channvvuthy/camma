<template>
    <VideoList/>
</template>

<script>
    // @ is an alias to /src

    import VideoList from "./Video/VideoList.vue"

    export default {
        name: 'Home',
        components: {
            VideoList
        }
    }
</script>
