<template>
    <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
         width="20" height="20"
         viewBox="0 0 172 172"
         style=" fill:#fa314a;">
        <g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter"
           stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none"
           font-size="none" text-anchor="none" style="mix-blend-mode: normal">
            <path d="M0,172v-172h172v172z" fill="none"></path>
            <g fill="#e74c3c">
                <path d="M69.83301,10.75c-8.81836,0 -16.08301,7.26465 -16.08301,16.08301v5.41699h-32.25v10.75h10.75v91.375c0,8.86035 7.26465,16.125 16.125,16.125h64.5c8.86035,0 16.125,-7.26465 16.125,-16.125v-91.375h10.75v-10.75h-32.25v-5.41699c0,-8.81836 -7.26465,-16.08301 -16.08301,-16.08301zM69.83301,21.5h21.58398c3.02344,0 5.33301,2.30957 5.33301,5.33301v5.41699h-32.25v-5.41699c0,-3.02344 2.30957,-5.33301 5.33301,-5.33301zM43,43h75.25v91.375c0,3.02344 -2.35156,5.375 -5.375,5.375h-64.5c-3.02344,0 -5.375,-2.35156 -5.375,-5.375zM53.75,53.75v75.25h10.75v-75.25zM75.25,53.75v75.25h10.75v-75.25zM96.75,53.75v75.25h10.75v-75.25z"></path>
            </g>
        </g>
    </svg>
</template>

<script>
    export default{
        name: "DeleteIcon"
    }
</script>