<template>
    <div>
        Grade
    </div>
</template>

<script>
    export default{
        name: "Grade"
    }
</script>