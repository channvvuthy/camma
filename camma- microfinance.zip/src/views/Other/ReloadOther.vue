<template>
  <div>Reload Other</div>
</template>
<script>
export default {
  created() {
    this.$router.push("/other");
  },
};
</script>